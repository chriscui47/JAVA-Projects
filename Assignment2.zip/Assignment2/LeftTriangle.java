//Name: Christopher Cui
//Student id: 260867703
public class LeftTriangle {
  
  
  public static void main(String[] args) {
    //take the rows of stars as input from args
    int numChars = Integer.parseInt(args[0]);
    
    printChars(numChars);
  }
  public static void printChars(int n){
    //output error if negative number
    if (n<0){
      System.out.println("Error: input value must be >= 0");
      return;
    }
    //go to next line until n number of rows reached
    for (int i =1; i<=n;i+=1){
      System.out.println();
      //print thea amount of stars according to which row you are in
      for (int j =1;j<=i;j+=1){
        System.out.print("*");
      }      
      
    }
    
  }

  
}
