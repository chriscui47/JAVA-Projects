//Name:Christopher Cui
//Student Id: 260867703

public class RightTriangle {
  
  
  public static void main(String[] args) {
    //take args as input, which is number of rows of stars
    int numChars = Integer.parseInt(args[0]);
    //call printchars function
    printChars(numChars);
  }
  public static void printChars(int n){
    //output error if negative number
    if (n<0){
      System.out.println("Error: input value must be >= 0");
      return;
    }
  //line skip for every row
    for (int i = 0; i < n; i++) {
     

      System.out.println();
      //put a space depending on which row you on, space needed to create right triangle. Spaces is n
      for (int x = n; x>=i; x--) {
        System.out.print(" "); 
      }
      
      //print number of stars depending on which row, ascending number of stars each row
      for (int x = 0; x<=i; x++){
        
        System.out.print("*");
      }

      
    }
    
  }

  
}
